#include <stdio.h>

int main(){
	int t; 
	FILE *fp = fopen("testdata.in", "r"); 
	fscanf(fp, "%d", &t); 
	
	int a[t]; 
	char b[t]; 
	for(int i =0; i<t; i++){
		fscanf(fp, "%d %[^\n]", &a[i], &b[i]); 
		printf("%s %s\n", a[i], b); 
	}
	return 0; 
} 
