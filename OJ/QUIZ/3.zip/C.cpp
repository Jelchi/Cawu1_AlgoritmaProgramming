#include <stdio.h>
#include <string.h>

int compare(const char *a, const char *b) {
  return strcmp(a, b);
}

void swap(char *a, char *b){
	char temp[101];
  	strcpy(temp, a);
  	strcpy(a, b);
  	strcpy(b, temp);
}

void sorting(char arr[][1001], int n){
	for (int i = 0; i < n - 1; i++) {
    for (int j = 0; j < n - i - 1; j++) {
      if (compare(arr[j], arr[j + 1]) > 0) {
        swap(arr[j], arr[j+1]);
      }
    }
  }
}


int main(){
	int n; 
	scanf("%d", &n); 
	
	char arr[n][1001]; 
	for(int i=0; i<n; i++){
		scanf("%s", &arr[i]); 
	}
	
		sorting(arr, n); 	
	
	for(int i=0; i<n; i++){
		printf("%s\n", arr[i]); 
	} 
	
	return 0; 
}
