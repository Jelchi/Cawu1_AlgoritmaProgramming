#include <stdio.h>

int min(int a[], int n){
	int min = a[0]; 
	for(int i=1; i<n; i++){
		if (a[i] > min){
			min=a[i]; 
		}
	}
}

int max(int s, int *a, int n){
	int count =0; 
	int sum = s;
	
 	while (sum > 0 && n > 0) {
   		int min_group = min(a, n); 
    	if (min_group <= sum) {
      		count++;
     		sum -= min_group; 
      		
			for (int i = 0; i < n; i++) {
       			if (a[i] == min_group) {
          			a[i] = a[n - 1];
        			break;
        		}
      		}
      		n--; 
   		} else {
		   break; 
    }
  }
  return count;
}
int main(){
	int s; 
	int n; 
	int a[101]; 
	scanf("%d", &s); 
	scanf("%d", &n); 
 
 
	for(int i=0; i<n; i++){
		scanf("%d", &a[i]); 
	}
	
	int result = max(s,a,n); 
	printf("%d\n", result); 
	return 0; 
	
}
