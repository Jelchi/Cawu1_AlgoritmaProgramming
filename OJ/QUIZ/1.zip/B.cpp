#include <stdio.h>

int main ()
{
	int T, I, N; 
	long long int M; 
	scanf("%d", &T); 
	
	for(int i=1; i<=T; i++)
	{
		scanf("%lld %d %d", &M, &I, &N);
		
		printf("Case #%d:\n", i);
		
		for(int j=1; j<=N; j++)
		{
			long long interest = (M*I*80)/12/100/100; 
			M+=interest; 
			printf("%d %lld\n", j, M); 
		  }  
	}
	return 0; 
}
