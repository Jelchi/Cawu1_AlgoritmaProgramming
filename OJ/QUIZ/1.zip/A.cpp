#include <stdio.h>
#include <string.h>

int Palindrome(char *str, int mulai, int selesai)
{
	while (mulai < selesai)
	{
		if(str[mulai] != str[selesai])
		{
			return 0; 
		}
		mulai++; 
		selesai ++; 
	}
	return 1; 
}

int main ()
{
	char S[1001]; 
	scanf("%s", &S); 
	
	int count = 0; 
	int n = strlen(S); 
	
	for(int i=0; i<n; i++)
	{
		for(int j=1; j<n; j++)
		{
			if(Palindrome(S, i, j))
			{
				count++;
			}
		}
	}
	printf("%d\n", count); 
	return 0; 
}
