#include <stdio.h>

int main() {
	int T;
	long long int N;
	long long int x;	

	scanf("%d", &T);
	
	for (int i = 1; i <= T; i++) {
		scanf("%lld", &N);
		
		long long int arr[N]; 
		long long int result = 0; 
		long long int counter = 0;
		
		for (int j = 0; j < N; j++) 
		{
			scanf("%lld", &arr[j]);
		}
		for (int j = 0; j < N - 1; j++) 
		{
			if (arr[j] == -1) 
			{
				continue;
			}
			counter = 0;
			
			if (arr[j] != -1 && arr[j] == arr[j + 1]) 
			{
				arr[j] = -1;
				arr[j + 1] = -1;
				counter++;
			}
			
			if (counter == 1) 
			{
				result++;
			}
		}
		
		printf("Case #%d: %lld\n", i, result);
	}

	return 0;
}

